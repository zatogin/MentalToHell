﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MentalToHell_3.Models.Reports
{
    public enum SortStateReport
    {
        NameAsc,    // по имени по возрастанию
        NameDesc,   // по имени по убыванию
        DateAsc, // по возрасту по возрастанию
        DateDesc
    }
}
