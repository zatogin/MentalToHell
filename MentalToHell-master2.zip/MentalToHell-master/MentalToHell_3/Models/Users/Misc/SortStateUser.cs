﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MentalToHell_3.Models.Users.Misc
{
    public enum SortStateUser
    {
        NameAsc,    // по имени по возрастанию
        NameDesc,   // по имени по убыванию
        DateAsc, // по возрасту по возрастанию
        DateDesc
    }
}
